import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { OCR, OCRSourceType, OCRResult } from '@awesome-cordova-plugins/ocr/ngx';
import { Camera, CameraOptions } from '@awesome-cordova-plugins/camera/ngx';


@Component({
  selector: 'app-tab5',
  templateUrl: './tab5.page.html',
  styleUrls: ['./tab5.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class Tab5Page implements OnInit {
  extractedText: string[] = [];                           // The text will be stored here
  extractedTextArray: string[] = []; 
  currentImage: any;
  currentImagebase64 : any;

  constructor( private mobileOCR: OCR, private camera: Camera ) { }

  ngOnInit(): void {
    //this.takePicture();
  }

  
// take the image using camera option and store it to show on page
  takePicture() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };
    
    this.camera.getPicture(options).then((imageData) => {
      this.currentImagebase64 =  'data:image/jpeg;base64,' + imageData;
      this.currentImage =  imageData;
      this.extractedText = [''];   // to clear old text for new image
    }, (err) => {
      // Handle error
      console.log("Camera issue:" + err);
    });
  }
  // Call the Extract OCR Funtion to get text from the image
  extractTextFromImage() {
    
    this.mobileOCR.recText(OCRSourceType.BASE64, this.currentImage)
      .then((res: OCRResult) => {
        this.extractedText = res.blocks.blocktext;
        //alert(this.extractedText);
      })
      .catch((error: any) => {
        console.error(error);
        alert(error + "Please Capture Image First");
      });

  
  }
  
}