import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Media, MediaObject } from '@awesome-cordova-plugins/media/ngx';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class Tab3Page implements OnInit {
  audio!: MediaObject;   //A variable to hold the MediaObject:
  buttonClicked: string = '';
  constructor(private media: Media) { }
  Message: string ='';

  ngOnInit() {
  }


 // Function to start recording the audio
  startRecord() {
    const file = this.media.create('audio.mp3');
    file.startRecord();
    this.audio = file;
    //alert('Recording started');
    this.buttonClicked ='success';
    this.Message = "Status: " +"Recording Started";
  }


 // Function to Stop recording the audio
  stopRecord() {
    this.audio.stopRecord();
    //alert('Recording Stopped');
    this.buttonClicked ='danger';
    this.Message = "Status: " +"Recording Stopped";
  }

  // Function to play the audio
  playAudio() {
    this.audio.play();
    //alert('Recording Saved Successfully');
    this.Message = "Status: " + "Recording Playing Now";
  }


  
}