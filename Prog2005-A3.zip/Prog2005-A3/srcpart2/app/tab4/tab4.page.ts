// src/app/tab4/tab4.page.ts

import { Component, OnInit } from '@angular/core';
import { DeviceOrientation, DeviceOrientationCompassHeading } from '@awesome-cordova-plugins/device-orientation/ngx';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page implements OnInit {
  headingData: DeviceOrientationCompassHeading | null = null;
  subscription: any;

  constructor(private deviceOrientation: DeviceOrientation) {}

  ngOnInit() {
    // Get the current device compass heading
    this.deviceOrientation.getCurrentHeading().then(
      (data: DeviceOrientationCompassHeading) => {
        this.headingData = data;
        console.log(data);
      },
      (error: any) => console.log(error)
    );

    // Watch the device compass heading change
    this.subscription = this.deviceOrientation.watchHeading().subscribe(
      (data: DeviceOrientationCompassHeading) => {
        this.headingData = data;
        console.log(data);
      }
    );
  }

  ngOnDestroy() {
    // Stop watching heading change when the component is destroyed
    this.subscription.unsubscribe();
  }
}
