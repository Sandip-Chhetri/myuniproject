import { Component, OnInit } from '@angular/core';
import { BarcodeScanner,BarcodeScannerOptions } from '@awesome-cordova-plugins/barcode-scanner/ngx';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  scannedData: any;
  encodedData: any ;
  encodeData: any;
  inputData: any;
  ScannedText : string ='';
  format : string = '';
  isCancelled : boolean = false;
  constructor(private barcodeScanner: BarcodeScanner) { }
  ngOnInit(): void {
    //throw new Error('Method not implemented.');
  }
  scanBarcode() {
    const options: BarcodeScannerOptions = {
      preferFrontCamera: false,
      showFlipCameraButton: true,
      showTorchButton: true,
      torchOn: false,
      prompt: 'Place a barcode inside the scan area',
      resultDisplayDuration: 500,
      formats: 'EAN_13,EAN_8,QR_CODE,PDF_417 ',
      orientation: 'portrait',
    };

    this.barcodeScanner.scan(options).then(barcodeData => {
      //console.log('Barcode data', JSON.stringify(barcodeData));
      this.scannedData = JSON.stringify(barcodeData);
      this.ScannedText = barcodeData.text;
      this.format = barcodeData.format;
      this.isCancelled = barcodeData.cancelled;

    }).catch(err => {
      console.log('Error', err);
    });
  }
}
