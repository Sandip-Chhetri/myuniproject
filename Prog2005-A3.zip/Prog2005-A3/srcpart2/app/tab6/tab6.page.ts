import { Component } from '@angular/core';
import { NativeAudio } from '@awesome-cordova-plugins/native-audio/ngx';
import { MediaCapture, MediaFile, CaptureError, CaptureAudioOptions } from '@awesome-cordova-plugins/media-capture/ngx';

@Component({
  selector: 'app-tab6',
  templateUrl: './tab6.page.html',
  styleUrls: ['./tab6.page.scss'],
})
export class Tab6Page {
  recording = false;
  audioFile: MediaFile | null = null;

  constructor(private mediaCapture: MediaCapture, private nativeAudio: NativeAudio) {}

  startRecording() {
    const options: CaptureAudioOptions = { limit: 1, duration: 10 };

    this.mediaCapture.captureAudio(options).then(
      (data: MediaFile[] | CaptureError) => {
        if (Array.isArray(data)) {
          this.audioFile = data[0];
          console.log('Audio File:', this.audioFile);
        } else {
          console.error('Error capturing audio', data);
        }
      }
    );
  }

  stopRecording() {
    this.recording = false;
    // Stop recording logic here if needed
  }

  playRecording() {
    if (this.audioFile) {
      this.nativeAudio.preloadSimple('uniqueId1', this.audioFile.fullPath).then(() => {
        this.nativeAudio.play('uniqueId1', () => console.log('Audio is done playing'));
      });
    }
  }

  stopPlayback() {
    this.nativeAudio.stop('uniqueId1');
  }
}
