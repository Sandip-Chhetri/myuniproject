import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PropertyService } from 'C:/Users/rawat/OneDrive/Desktop/ASS3/ionic1/src/app/Property.service';  // Update the path
import { PropertyData } from '../PropertyData';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab6',
  templateUrl: 'tab6.page.html',
  styleUrls: ['tab6.page.scss'],
  providers: [PropertyService]
})
export class Tab6Page {

  propertyId: number = 0;
  property!: PropertyData;

  constructor(
    private activatedRoute: ActivatedRoute,
    private propertyService: PropertyService,
    private navCtrl: NavController
  ) {}

  ionViewDidEnter() {
   this.propertyId = +this.activatedRoute.snapshot.paramMap.get('id')! ?? 0;
   this.property = this.propertyService.getProperties().find((p: PropertyData) => p.propertyId === this.propertyId)!;
  }

  updateProperty() {
    this.propertyService.updateProperty(this.property);
    // Optionally, navigate back to the property list page
    this.navCtrl.navigateBack('/property-list');
  }

  deleteProperty() {
    this.propertyService.deleteProperty(this.propertyId);
    // Optionally, navigate back to the property list page
    this.navCtrl.navigateBack('/property-list');
  }
}
