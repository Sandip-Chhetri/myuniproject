// search-properties.page.ts
import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
   selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
})
export class Tab4Page {
  properties: any[] = []; // Assuming you have an array of properties
  searchResults: any[] = [];
  searchTerm: string = '';

  constructor(private navCtrl: NavController) {}

  searchProperties() {
    this.searchResults = this.properties.filter(property =>
      property.propertyName.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  viewPropertyDetails(property: any) {
    // Navigate to a page to display property details
    this.navCtrl.navigateForward(`/property-details/${property.propertyId}`);
  }
}
