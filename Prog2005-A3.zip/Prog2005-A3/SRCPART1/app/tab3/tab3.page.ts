import { Component } from '@angular/core';
import { PropertyData } from 'src/app/PropertyData';
import { PropertyService } from 'C:/Users/rawat/OneDrive/Desktop/ASS3/ionic1/src/app/Property.service';



@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

property: PropertyData = new PropertyData( 0,
  '',          
  '',          
  '',         
  'For Sale',
  0,           
  0,           
  0,           
  0,           
  new Date(),  
  '',          
  '',         
  '', 
  false
  );
  txtID:String="";//reference variable of ID's input field
   txtName:String="";
   txtAddress:String="";//reference variable of ID's input field
   txtType:String="";
   propertyType:string = "";
  

listingType: string = "";

numBedrooms: number = 0;

numBathrooms: number = 0;

numParking: number = 0;


price: number = 0;

availableDate: string = ""; 

agentName: string = "";

agentEmail: string = "";


agentContactNumber: string = "";

 saveProperty():void {
    //add to an array
	alert("New Property Added");
    console.log('Save button clicked!');
  }

  constructor( private propertyService: PropertyService) {}
  
  addProperty():void{
    alert("ID: " + this.property.propertyId);
    alert("Name: " + this.property.propertyName);
    alert("Address: " + this.property.propertyAddress);
    alert("Property Type: " + this.property.propertyType);
    alert("Listing Type: " + this.property.listingType);
    alert("Bedrooms: " + this.property.bedrooms);
    alert("Bathrooms: " + this.property.bathrooms);
    alert("Parking Spaces: " + this.property.parkingSpaces);
    alert("Asking Price: " + this.property.askingPrice);
    alert("Available From: " + this.property.availableFrom);
    alert("Agent Name: " + this.property.agentName);
    alert("Agent Email: " + this.property.agentEmail);
    alert("Agent Contact Number: " + this.property.agentContactNumber);
	 
   

   this.propertyService.insertProperty(
      this.property.propertyId,
      this.property.propertyName,
      this.property.propertyAddress,
      this.property.propertyType,
      this.property.listingType,
      this.property.bedrooms,
      this.property.bathrooms,
      this.property.parkingSpaces,
      this.property.askingPrice,
      this.property.availableFrom,
      this.property.agentName,
      this.property.agentEmail,
      this.property.agentContactNumber,
	  this.property.exclusive // Pass exclusive property
	  );
	  
	alert("New Property Added");
	
}}
