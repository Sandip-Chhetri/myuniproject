export class PropertyData {
  propertyId: number;
  propertyName: string;
  propertyAddress: string;
  propertyType: string;
  listingType: 'For Sale' | 'For Rent';
  bedrooms: number;
  bathrooms: number;
  parkingSpaces: number;
  askingPrice: number;
  availableFrom: Date;
  agentName: string;
  agentEmail: string;
  agentContactNumber: string;
   exclusive: boolean;

  constructor(
     Id: number,
     name: string,
    address: string,
     propertyType: string,
    listingType: 'For Sale' | 'For Rent',
    bedrooms: number,
    bathrooms: number,
    parkingSpaces: number,
     askingPrice: number,
    availableFrom: Date,
    agentName: string,
     agentEmail: string,
     agentContactNumber: string,
	     exclusive: boolean,
	 
  ) {
    this.propertyId = Id;
    this.propertyName = name;
    this.propertyAddress = address;
    this.propertyType = propertyType;
    this.listingType = listingType;
    this.bedrooms = bedrooms;
    this.bathrooms = bathrooms;
    this.parkingSpaces = parkingSpaces;
    this.askingPrice = askingPrice;
    this.availableFrom = availableFrom;
    this.agentName = agentName;
    this.agentEmail = agentEmail;
    this.agentContactNumber = agentContactNumber;
	 this.exclusive = exclusive;
}}
