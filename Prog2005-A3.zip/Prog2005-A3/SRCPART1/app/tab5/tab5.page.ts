// exclusive-listings.page.ts
import { Component } from '@angular/core';
import { PropertyService } from '../../app/Property.service';
import { PropertyData } from 'src/app/PropertyData';

@Component({
  selector: 'app-tab5',
  templateUrl: 'tab5.page.html',
  styleUrls: ['tab5.page.scss']
})
export class Tab5Page {
  exclusiveProperties: PropertyData[] = [];

  constructor(private propertyService: PropertyService) {}

  ionViewWillEnter() {
    // Fetch the list of exclusive properties
    this.exclusiveProperties = this.propertyService.getExclusiveProperties();
  }
}
