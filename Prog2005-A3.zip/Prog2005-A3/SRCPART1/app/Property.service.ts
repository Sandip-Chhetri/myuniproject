import { Injectable } from '@angular/core';
import { PropertyData } from 'src/app/PropertyData';

@Injectable({
  providedIn: 'root'
})
export class PropertyService {

  arrProperty: PropertyData[] = [];

  constructor() {}

  public getProperties(): PropertyData[] {
    if (this.arrProperty) {
      alert(this.arrProperty.length);
      alert(JSON.stringify(this.arrProperty)); // Use JSON.stringify to display the array.
    }
    return this.arrProperty; // Close the method properly
  }

  public getExclusiveProperties(): PropertyData[] {
    return this.arrProperty.filter(property => property.exclusive);
  }

  public insertProperty(
    id: number,
    name: string,
    address: string,
    propertyType: string,
    listingType: 'For Sale' | 'For Rent',
    bedrooms: number,
    bathrooms: number,
    parkingSpaces: number,
    askingPrice: number,
    availableFrom: Date,
    agentName: string,
    agentEmail: string,
    agentContactNumber: string,
    exclusive: boolean // Add exclusive property
  ): void {
    let newProperty: PropertyData = new PropertyData(
      id,
      name,
      address,
      propertyType,
      listingType,
      bedrooms,
      bathrooms,
      parkingSpaces,
      askingPrice,
      availableFrom,
      agentName,
      agentEmail,
      agentContactNumber,
      exclusive // Set exclusive property
    );
    this.arrProperty.push(newProperty);
    alert(JSON.stringify(this.arrProperty));
  }

  public updateProperty(updatedProperty: PropertyData): void {
    const index = this.arrProperty.findIndex(p => p.propertyId === updatedProperty.propertyId);

    if (index !== -1) {
      this.arrProperty[index] = updatedProperty;
    }
  }

  public deleteProperty(propertyId: number): void {
    this.arrProperty = this.arrProperty.filter(p => p.propertyId !== propertyId);
  }
}
