import { Component } from '@angular/core';
import { PropertyData } from 'src/app/PropertyData';

import { PropertyService } from 'C:/Users/rawat/OneDrive/Desktop/ASS3/ionic1/src/app/Property.service';
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

arrProperty:PropertyData[]=[];



  constructor(private propertyService:PropertyService) {}
listallProperties():void{
alert(this.arrProperty);
this.arrProperty=this.propertyService.getProperties();
 console.log(this.arrProperty);
}
}
